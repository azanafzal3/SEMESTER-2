#pragma once
class Feedback
{
	char review[300];

public:
	char* getReview();

	void setReview(char*);
};
